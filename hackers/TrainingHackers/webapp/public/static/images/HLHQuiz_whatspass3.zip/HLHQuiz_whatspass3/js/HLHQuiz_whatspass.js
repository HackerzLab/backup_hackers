var PASS = "4"+"|"+"9"+"|"+"2"+"|"+"7"+"|"+"a"+"|"+"a"+"|"+"0"+"|"+"c"+"|"+"a"+"|"+"4"+"|"+"a"+"|"+"2"+"|"+"b"+"|"+"0"+"|"+"d"+"|"+"9",FLAG = "B"+"|"+"L"+"|"+"O"+"|"+"O"+"|"+"D"+"|"+"Y"+"|"+"-"+"|"+"X";
var checkPassword = function(value) {if (value == PASS.split("|").join("")) {console.log("Your FLAG is HLH="+FLAG.split("|").join(""));} else {console.log("That's too bad.");}};
