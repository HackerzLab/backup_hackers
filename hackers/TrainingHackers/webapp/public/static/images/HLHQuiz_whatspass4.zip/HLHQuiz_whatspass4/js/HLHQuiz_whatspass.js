var PASS = "nxvdndeholhyhu";
var FLAG = "rev-4011";

var checkPassword = function(value) {
  if (value == caeserCipherDecryption(PASS, 3)) {
    console.log("Your FLAG is HLH="+caeserCipherDecryption(FLAG, 3));
  } else {
    console.log("That's too bad.");
  }
};

/**
 * シーザー暗号で暗号化
 * ・文字は全て小文字化
 * ・「abz」を1文字ずらすと 「bca」になる
 * ・「ABZ」を1文字ずらすと 「BCA」になる
 * ・アルファベット以外は変換しない
 * @param {string} plain - 平文
 * @param {number} shift - ずらす文字数
 * @return {string} 暗号化文字列
 */
var caeserCipherEncryption = function(plain, shift) {
  var lower_plain = plain.toLowerCase();
  var cipher = "";
  for (i=0; i<lower_plain.length; i++) {
    // アルファベット以外は変換しない
    charat = lower_plain.charAt(i);
    if (charat < 'a' || charat > 'z') {
      cipher += charat;
      continue;
    }
    c = lower_plain.charCodeAt(i);
    if (charat == 'z') {
      e = c + shift - 26;
    } else {
      e = c + shift;
    }
    
    cipher += String.fromCharCode(e);
  }
  return cipher;
};

/**
 * シーザー暗号を複合化
 * ・文字は全て小文字化
 * ・「bca」を1文字戻すと 「abz」になる
 * ・「BCA」を1文字戻すと 「ABZ」になる
 * ・アルファベット以外は変換しない
 * @param {string} cipher - 暗号文
 * @param {number} shift - ずらす文字数
 * @return {string} 復号化(平文)文字列
 */
var caeserCipherDecryption = function(cipher, shift) {
  var lower_cipher = cipher.toLowerCase();
  var plain = "";
  for (i=0; i<lower_cipher.length; i++) {

    // アルファベット以外は変換しない
    charat = lower_cipher.charAt(i);
    if (charat < 'a' || charat > 'z') {
      plain += charat;
      continue;
    } 
    
    c = lower_cipher.charCodeAt(i);
    if (charat == 'a') {
      e = c - shift + 26;
    } else {
      e = c - shift;
    }
    
    plain += String.fromCharCode(e);
  }
  return plain;
};
