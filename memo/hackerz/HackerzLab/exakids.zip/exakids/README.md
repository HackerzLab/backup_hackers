# NAME

exakids_contest - エクサキッズ、子供プログラミングコンテストのサイト

# SYNOPSIS

## URL

確認用の暫定

```
http://yonabemt.sakura.ne.jp/exakids/contest/index.html
```

## DEPLOY

```
(鍵認証による接続 ローカルマシンより)
$ ssh yonabemt@yonabemt.sakura.ne.jp

(さくらのレンタルサーバーは csh)
% pwd
/home/yonabemt

(移動後 git を最新の状態に)
% cd www/exakids/
% pwd
/home/yonabemt/www/exakids

% git fetch
% git pull origin master
```

# DESCRIPTION

## テンプレート

### massively

- <https://html5up.net/>
- <https://html5up.net/massively>

### その他、参考

- <http://photoshopvip.net/102391> - テンプレ関連記事
- <http://www.springin.org/jp/fca2017/> - サイトレイアウトの参考

# TODO

- ソースコード引き渡しのことを考えてディレクトリ構成を見直しておく
- エントリーページに具体的な応募のステップ書いておくとよい(スクリーンションをのせたい)
- google from について
    - 入力後の完了ページの文言を変更するのは難しそう
    - 入力後に入力者にお知らせメールを送る方法はいくつか事例あり
    - 入力後に管理者にお知らせメールはやる方法あり
    - 入力毎に受付番号の代替えとなるユニークなIDを作成する方法は要検討
    - 添付ファイルの送りかた、いくつか事例あり
    - from は個人の gmail に紐づいているので最終的に変更
- SNS のリンクはフェイスブックとLINEのみアイコン変更
    - <https://nelog.jp/web-service-icon-fonts> - webフォント記事
- ページの各文言は全体的にみなおし、内容の重複がないかなど
- 公開サーバーは別途指定がある予定
- 公開は9月中旬ごろを予定

# OPTIONS

# EXAMPLES

# SEE ALSO

# HISTORY
